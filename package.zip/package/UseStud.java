package pack2;
import pack1.Student;
class UseStud extends Student
{
	void show()
	{
	//System.out.println("pho :"+pho);
     //System.out.println("prn :"+prn);
	 System.out.println("Address :"+address);
	 System.out.println("Per :"+per);

	
	}
	
	public static void main(String[] args) 
	{
		UseStud us=new UseStud();
		us.show();
	}
}


/*// 
// 
 Student s=new Student();
    // System.out.println("pho :"+s.pho);
    // System.out.println("prn :"+s.prn);
	 //System.out.println("Address :"+s.address);
	 System.out.println("Per :"+s.per);

 //System.out.println("pho :"+pho);
    // System.out.println("prn :"+prn);
	 ///System.out.println("Address :"+address);
	 //System.out.println("Per :"+per);

	 */