package pack1;
 public class Student
{
	private int pho=1234;
	        int prn=1022;
    protected String address="Kothurd";
	public float per=92.90f;

   
}
